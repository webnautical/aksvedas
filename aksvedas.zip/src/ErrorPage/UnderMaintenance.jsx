import React from 'react'

const UnderMaintenance = () => {
  return (
    <div>UnderMaintenance</div>
  )
}

export default UnderMaintenance