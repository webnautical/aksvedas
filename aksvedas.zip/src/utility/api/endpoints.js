
export const ADMIN_LOGIN = ''
export const GET_CATEGORIES= '/get-categories'