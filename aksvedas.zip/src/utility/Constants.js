export const SOMETHING_ERR="Something wen't wrong"
export const SERVER_ERR="Something wen't wrong"