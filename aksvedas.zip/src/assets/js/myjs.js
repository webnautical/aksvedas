document.getElementById('viewSales').addEventListener('click', () => {
    alert('OK')
 });