import React from 'react'

export const TermsConditions = () => {
  return (
    <div>TermsConditions</div>
  )
}
